#!/usr/bin/env bash
set -euo pipefail

BASE_REF="${1:-main}"
HEAD_REF="${2:-HEAD}"

git diff --name-only "$BASE_REF" "$HEAD_REF" | sed '/^$/d' > changed-files.txt

{
  echo "# Changed Files"
  echo
  echo "Base: $BASE_REF"
  echo "Head: $HEAD_REF"
  echo
  cat changed-files.txt
} > changed-files.md

echo "Wrote changed-files.txt and changed-files.md"
