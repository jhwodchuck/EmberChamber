#!/usr/bin/env bash
set -euo pipefail

BASE_REF="${1:-main}"
HEAD_REF="${2:-HEAD}"
REVIEW_TARGET="${3:-manual-review}"

bash scripts/collect_changed_files.sh "$BASE_REF" "$HEAD_REF"
bash scripts/collect_repo_facts.sh repo-facts.md
python3 scripts/build_evidence_pack.py --review-target "$REVIEW_TARGET" --base-ref "$BASE_REF" --head-ref "$HEAD_REF" --changed-files changed-files.txt --out evidence-pack.md
python3 scripts/route_reviewers.py changed-files.txt > recommended-reviewers.txt

echo "Generated:"
echo "  - changed-files.txt"
echo "  - changed-files.md"
echo "  - repo-facts.md"
echo "  - evidence-pack.md"
echo "  - recommended-reviewers.txt"
