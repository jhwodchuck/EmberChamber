# C-09 — Security, Privacy, and Crypto Reviewer

## Included files

- `personas/C-09-Security-Privacy-Crypto-Reviewer.md`
- `shared/*`
- `templates/*`
- `scripts/*`

## Minimal input set

For routine use, give the agent:
1. the persona prompt
2. the shared files
3. `review-request.yaml`
4. `evidence-pack.md`
5. only the most relevant changed snippets

## Output requirement

The agent should write a Markdown report with YAML frontmatter using `templates/report-template.md`.
